Ce repository contient les fichiers nécessaires aux activités 2 et 3 du cours Créez des animations CSS modernes sur [OpenClassrooms](http://openclassrooms.com/).

Parcourez les dossiers de ce repo pour obtenir plus de détails sur chacune des deux activités 🤩
