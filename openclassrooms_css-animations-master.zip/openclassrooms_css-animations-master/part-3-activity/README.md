Vous trouverez ici les fichiers nécessaires pour l'activité de la partie 3 du cours Créez des animations CSS modernes sur [OpenClassrooms](http://openclassrooms.com/).

Lorsque vous travaillerez sur cette activité, si vous voulez utiliser les fichiers sass plutôt que d'éditer le code css directement, il vous faudra [sass](https://sass-lang.com/) installé sur votre machine. Exécutez simplement 

```
$ sass --watch scss:css
```
 
 dans votre dossier local pour compiler les fichiers sass en un fichier css référencé dans le `index.html`

 **Happy hacking!**

---

Si vous avez atterri ici par hasard, jetez un oeil au cours sur OpenClassrooms. Vous pourrez alors vite revenir ici pour l'activité de la partie 3 🚀
